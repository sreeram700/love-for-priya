
import React from 'react';
import LoveForMyWife from './LoveForMyWife';

function App() {
  return <LoveForMyWife />;
}

export default App;
